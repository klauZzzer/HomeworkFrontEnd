//1
console.log("Задание 1");

for(let a=0; a<=10; a++) {
    if(a == 0){
        console.log("старт");
    } else if(a > 0 && a < 10) {
        console.log(a);
    } else {
        console.log("финиш");
    }
}

//2
console.log("Задание 2");

for(let b=10; b<=99; b++) {
    if(b % 3 == 0 && b % 5 == 0) {
        console.log(b);
    } else {
        continue;
    }
}

//3
console.log("Задание 3");

let number1 = +prompt("First Number");
let number2 = +prompt("Second Number");
if(number1 < number2) {
    for( c=number1; c <= number2; c++){
       if(number1 == c) {
            continue;
       } else {
        number1 = number1 + c;
       }
    }
    console.log(number1);
} else {
    for( c=number2; c <= number1; c++){
        if(number2 == c) {
             continue;
        } else {
         number2 = number2 + c;
        }
     }
     console.log(number2);
}

//4
console.log("Задание 4");

let number3 = +prompt("Number");
for(d=0; d<=number3; d++) {
    if(number3 % d == 0) {
        console.log(d);
    } else {
        continue;
    }
}

//5
console.log("Задание 5");

let pol = 0;
let otr = 0;
let nul = 0;
let chet = 0;
let nechet = 0;
for(e=0; e<10; e++) {
    let userNum = +prompt("Enter random number")
    if(userNum > 0) {
        pol = pol + 1;
    } else if(userNum < 0) {
        otr = otr + 1;
    } else {
        nul = nul + 1;
    }

    if(userNum % 2 == 0) {
        chet = chet + 1;
    } else {
        nechet = nechet + 1;
    }
    console.log(pol);
    console.log(otr);
    console.log(nul);
    console.log(chet);
    console.log(nechet);
    console.log("______________________");
}

